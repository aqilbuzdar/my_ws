#! /usr/bin/env python3

import rospy

from sensor_msgs.msg import LaserScan 

def callback_laser(msg):
    # Calculate the minimum range values for each sector
    sector1 = min(msg.ranges[0:143])
    sector2 = min(msg.ranges[144:287])
    sector3 = min(msg.ranges[288:431])
    sector4 = min(msg.ranges[432:575])
    sector5 = min(msg.ranges[576:719])
    
    # Determine which sector has the minimum range
    sectors = [sector1, sector2, sector3, sector4, sector5]
    min_sector = sectors.index(min(sectors)) + 1  # Add 1 to make it 1-based
    
    rospy.loginfo(f"Minimum range in Sector {min_sector}: {min(sectors)}")

def main():
    rospy.init_node("reading_laser")

    sub = rospy.Subscriber("/scan", LaserScan, callback_laser)

    rospy.spin()

if __name__=='__main__':
    main()
